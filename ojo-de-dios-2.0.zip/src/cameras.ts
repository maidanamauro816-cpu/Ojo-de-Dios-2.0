declare const Cesium: any;

const esc = (value: any) =>
  String(value ?? '').replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch] || ch));

const first = (...values: any[]) => values.find((value) => value !== undefined && value !== null && value !== '');

function safeUrl(value: any): string {
  if (!value) return '';
  try {
    const url = new URL(String(value));
    return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
  } catch {
    return '';
  }
}

function normalizeCamera(row: any, index: number) {
  const p = row?.properties || row || {};
  const coords = row?.geometry?.coordinates;
  const lat = Number(first(p.lat, p.latitude, p.y, coords?.[1]));
  const lon = Number(first(p.lon, p.lng, p.longitude, p.x, coords?.[0]));
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) return null;

  const page = first(p.page_url, p.source_url, p.website, p.url, row?.url);
  const stream = first(p.stream_url, p.hls_url, p.mjpeg_url, p.video_url, p.feed_url);
  const image = first(p.image_url, p.snapshot_url, p.frame_url, p.thumbnail, p.image);

  return {
    id: String(first(p.id, p.camera_id, row?.id, `public-camera-${index}`)),
    name: String(first(p.name, p.title, p.label, p.description, 'Cámara pública')),
    location: String(first(p.location, p.city, p.place, p.address, p.region, 'Ubicación no especificada')),
    country: String(first(p.country, p.country_name, p.country_code, '')),
    category: String(first(p.category, p.kind, p.type, p.camera_type, 'Pública')),
    provider: String(first(p.source_name, p.source, p.operator, p.provider, 'Operador público')),
    lat,
    lon,
    pageUrl: safeUrl(page),
    streamUrl: safeUrl(stream),
    imageUrl: safeUrl(image),
    active: p.active !== false && p.is_active !== false && p.status !== 'inactive'
  };
}

function cameraCenter(viewer: any) {
  const canvas = viewer.scene.canvas;
  const center = new Cesium.Cartesian2(canvas.clientWidth / 2, canvas.clientHeight / 2);
  const point = viewer.camera.pickEllipsoid(center, viewer.scene.globe.ellipsoid) || Cesium.Cartesian3.fromDegrees(-58.98, -27.46, 0);
  const geo = Cesium.Cartographic.fromCartesian(point);
  return { lat: Cesium.Math.toDegrees(geo.latitude), lon: Cesium.Math.toDegrees(geo.longitude) };
}

export function initCameraLayer(viewer: any, onStatus = (_s: string) => {}, onHint = (_h: string) => {}) {
  const entities = new Map<string, any>();
  const list = document.getElementById('camera-list');
  const tools = document.getElementById('camera-tools');
  const detail = document.getElementById('camera-viewer');
  const close = document.getElementById('close-camera');
  const title = document.getElementById('camera-viewer-title');
  const meta = document.getElementById('camera-viewer-meta');
  const media = document.getElementById('camera-media');
  const sourceLink = document.getElementById('camera-source-link') as HTMLAnchorElement;

  let enabled = false;
  let busy = false;
  let lastFetch = 0;
  let selected: any = null;

  function closeViewer() {
    if (detail) detail.hidden = true;
    if (media) media.innerHTML = '';
    selected = null;
  }

  close?.addEventListener('click', closeViewer);

  function showCamera(camera: any) {
    selected = camera;
    if (title) title.textContent = camera.name;
    if (meta) meta.textContent = [camera.location, camera.country, camera.category, camera.provider].filter(Boolean).join(' · ');
    if (sourceLink) {
      sourceLink.href = camera.pageUrl || camera.streamUrl || camera.imageUrl || 'https://opencctv.org/open-cameras';
      sourceLink.hidden = !(camera.pageUrl || camera.streamUrl || camera.imageUrl);
    }
    if (media) {
      media.innerHTML = '';
      if (camera.streamUrl && /\.m3u8($|\?)/i.test(camera.streamUrl)) {
        const video = document.createElement('video');
        video.controls = true;
        video.autoplay = true;
        video.playsInline = true;
        video.className = 'camera-video';
        media.appendChild(video);
        if ((window as any).Hls && (window as any).Hls.isSupported()) {
          const hls = new (window as any).Hls({ enableWorker: true, lowLatencyMode: true });
          hls.loadSource(camera.streamUrl);
          hls.attachMedia(video);
          video.addEventListener('emptied', () => hls.destroy(), { once: true });
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          video.src = camera.streamUrl;
        } else {
          media.textContent = 'Este dispositivo requiere soporte HLS o abrir la señal directa en la web del operador.';
        }
      } else if (camera.streamUrl && /youtube\.com|youtu\.be/i.test(camera.streamUrl)) {
        const match = camera.streamUrl.match(/(?:youtu\.be\/|v=|embed\/|live\/)([\w-]{6,})/);
        if (match) {
          const frame = document.createElement('iframe');
          frame.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(match[1])}`;
          frame.allow = 'autoplay; encrypted-media; picture-in-picture';
          frame.allowFullscreen = true;
          frame.className = 'camera-frame';
          media.appendChild(frame);
        }
      } else if (camera.imageUrl) {
        const image = document.createElement('img');
        image.src = camera.imageUrl;
        image.alt = camera.name;
        image.className = 'camera-frame-image';
        image.referrerPolicy = 'no-referrer';
        media.appendChild(image);
      } else {
        media.textContent = 'La ficha está disponible. Utilice el enlace de la fuente para visualizar la transmisión del operador.';
      }
    }
    if (detail) detail.hidden = false;
  }

  function render() {
    if (!list) return;
    const cameras = Array.from(entities.values()).sort((a, b) => a.name.localeCompare(b.name));
    if (!cameras.length) {
      list.innerHTML = '<span class="muted">No hay cámaras reportadas en esta zona. Desplace el mapa y actualice.</span>';
      return;
    }

    list.innerHTML = cameras
      .slice(0, 60)
      .map(
        (camera) =>
          `<button class="camera-row" data-camera="${esc(camera.id)}">
            <span class="camera-dot"></span>
            <span>
              <b>${esc(camera.name)}</b>
              <small>${esc([camera.location, camera.category].filter(Boolean).join(' · '))}</small>
            </span>
            <i>›</i>
          </button>`
      )
      .join('');

    list.querySelectorAll('[data-camera]').forEach((button) =>
      button.addEventListener('click', () => {
        const camId = (button as HTMLElement).dataset.camera;
        const camera = camId ? entities.get(camId) : null;
        if (!camera) return;
        viewer.selectedEntity = camera.entity;
        viewer.flyTo(camera.entity, {
          duration: 1.2,
          offset: new Cesium.HeadingPitchRange(0, Cesium.Math.toRadians(-35), 180000)
        });
        showCamera(camera);
      })
    );
  }

  async function refresh(force = false) {
    if (!enabled || busy || (!force && Date.now() - lastFetch < 60000)) return;
    busy = true;
    onStatus('Buscando cámaras públicas…');

    try {
      const center = cameraCenter(viewer);
      const response = await fetch(`/api/cameras?lat=${encodeURIComponent(center.lat.toFixed(4))}&lon=${encodeURIComponent(center.lon.toFixed(4))}&radius=1200`, { cache: 'no-store' });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Error del directorio');

      const incoming = (data.cameras || []).map(normalizeCamera).filter((camera: any) => camera && camera.active);
      const visibleIds = new Set(incoming.map((camera: any) => camera.id));

      incoming.forEach((camera: any) => {
        let item = entities.get(camera.id);
        const position = Cesium.Cartesian3.fromDegrees(camera.lon, camera.lat, 0);
        if (!item) {
          const entity = viewer.entities.add({
            name: camera.name,
            position,
            point: {
              pixelSize: 9,
              color: Cesium.Color.fromCssColorString('#43e6a8'),
              outlineColor: Cesium.Color.WHITE,
              outlineWidth: 1.5,
              disableDepthTestDistance: 1e7
            },
            label: {
              text: '📷 CAM',
              font: 'bold 9px monospace',
              fillColor: Cesium.Color.fromCssColorString('#9dffd8'),
              outlineColor: Cesium.Color.BLACK,
              outlineWidth: 3,
              style: Cesium.LabelStyle.FILL_AND_OUTLINE,
              pixelOffset: new Cesium.Cartesian2(0, -14),
              scaleByDistance: new Cesium.NearFarScalar(1e5, 1, 5e6, 0.4),
              disableDepthTestDistance: 1e7
            },
            description: `<b>${esc(camera.name)}</b><br>${esc(camera.location)}<br>Operador: ${esc(camera.provider)}`
          });
          item = { ...camera, entity };
          entities.set(camera.id, item);
        } else {
          Object.assign(item, camera);
          item.entity.position = position;
          item.entity.show = true;
        }
      });

      for (const [id, item] of entities) {
        if (!visibleIds.has(id)) {
          viewer.entities.remove(item.entity);
          entities.delete(id);
        }
      }

      lastFetch = Date.now();
      render();
      onStatus(`${incoming.length} cámaras públicas detectadas`);
      onHint('Cámaras abiertas de acceso público. Selecciónelas para desplegar la transmisión o fotografía periódica.');
    } catch (error: any) {
      onStatus('Directorio en espera');
      if (list) list.innerHTML = `<span class="muted">${esc(error.message)}</span>`;
    } finally {
      busy = false;
    }
  }

  function setEnabled(value: boolean) {
    enabled = value;
    if (tools) tools.hidden = !value;
    if (value) {
      refresh(true);
    } else {
      for (const item of entities.values()) item.entity.show = false;
      closeViewer();
    }
    if (value) {
      for (const item of entities.values()) item.entity.show = true;
    }
    onStatus(value ? 'Cámaras públicas activas' : 'Desactivadas');
  }

  document.getElementById('refresh-cameras')?.addEventListener('click', () => refresh(true));
  viewer.camera.moveEnd.addEventListener(() => {
    if (enabled) refresh(false);
  });

  return { setEnabled, refresh };
}
