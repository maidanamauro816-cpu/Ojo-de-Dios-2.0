import { defineConfig } from 'vite';
import fs from 'fs';
import path from 'path';

function ojoDeDiosApiPlugin() {
  const tleCache = new Map<string, { data: string; timestamp: number }>();
  const DEFAULT_TLE_MAP: Record<string, { catnr: string; fallbackTle: string }> = {
    iss: {
      catnr: '25544',
      fallbackTle: `1 25544U 98067A   24305.54583333  .00016717  00000+0  30000-3 0  9993\n2 25544  51.6415 160.7123 0005845 125.4521 234.6712 15.49815340478912`
    },
    tiangong: {
      catnr: '48274',
      fallbackTle: `1 48274U 21035A   24305.51234567  .00012345  00000+0  20000-3 0  9991\n2 48274  41.4723 182.3456 0003412 145.2134 214.8123 15.60234120194812`
    },
    hubble: {
      catnr: '20580',
      fallbackTle: `1 20580U 90037B   24305.48912345  .00001524  00000+0  65000-4 0  9997\n2 20580  28.4691 112.5482 0002874  98.4123 261.7123 15.08912340854215`
    }
  };

  return {
    name: 'ojo-de-dios-api',
    configureServer(server: any) {
      server.middlewares.use(async (req: any, res: any, next: any) => {
        if (!req.url) return next();

        const url = new URL(req.url, 'http://localhost:3000');

        if (url.pathname === '/ojo-de-dios-2.0.zip' || url.pathname === '/api/download/zip') {
          const zipPath = path.resolve(process.cwd(), 'public/ojo-de-dios-2.0.zip');
          if (fs.existsSync(zipPath)) {
            res.setHeader('Content-Type', 'application/zip');
            res.setHeader('Content-Disposition', 'attachment; filename="ojo-de-dios-2.0.zip"');
            const stream = fs.createReadStream(zipPath);
            return stream.pipe(res);
          }
        }

        if (!req.url.startsWith('/api/')) {
          return next();
        }
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Accept');

        if (req.method === 'OPTIONS') {
          res.statusCode = 204;
          return res.end();
        }

        if (url.pathname === '/api/health') {
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ status: 'ok', app: 'Ojo de Dios 2.0', version: '2.0.0' }));
        }

        if (url.pathname === '/api/adsb') {
          const lat = Number(url.searchParams.get('lat'));
          const lon = Number(url.searchParams.get('lon'));
          const dist = Number(url.searchParams.get('dist') || 250);

          if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(dist)) {
            res.statusCode = 400;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: 'Invalid parameters', ac: [] }));
          }

          const targetUrl = `https://api.adsb.lol/v2/lat/${lat}/lon/${lon}/dist/${Math.round(dist)}`;
          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), 8000);
          try {
            const resp = await fetch(targetUrl, {
              headers: { Accept: 'application/json', 'User-Agent': 'OjoDeDios/2.0' },
              signal: ctrl.signal
            });
            const text = await resp.text();
            res.statusCode = resp.status;
            res.setHeader('Content-Type', 'application/json');
            return res.end(text);
          } catch (err: any) {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ ac: [], warning: 'ADSB.lol gateway unavailable' }));
          } finally {
            clearTimeout(t);
          }
        }

        if (url.pathname === '/api/aircraft') {
          const hex = (url.searchParams.get('hex') || '').trim().toLowerCase();
          const callsign = (url.searchParams.get('callsign') || '').trim().toUpperCase();

          if (!/^[0-9a-f]{6}$/.test(hex)) {
            res.statusCode = 400;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: 'Invalid hex' }));
          }

          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), 7000);
          try {
            const reqs: Promise<any>[] = [
              fetch(`https://hexdb.io/api/v2/aircraft/${hex}`, { headers: { Accept: 'application/json' }, signal: ctrl.signal })
            ];
            if (callsign && /^[A-Z0-9-]{2,12}$/.test(callsign)) {
              reqs.push(fetch(`https://hexdb.io/api/v2/routes/${encodeURIComponent(callsign)}`, { headers: { Accept: 'application/json' }, signal: ctrl.signal }));
            }
            const settled = await Promise.allSettled(reqs);
            let aircraft = null;
            let route = null;
            if (settled[0].status === 'fulfilled' && settled[0].value.ok) {
              aircraft = await settled[0].value.json();
            }
            if (settled[1]?.status === 'fulfilled' && settled[1].value.ok) {
              route = await settled[1].value.json();
            }
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ aircraft, route, source: 'hexdb.io' }));
          } catch (err) {
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ aircraft: null, route: null }));
          } finally {
            clearTimeout(t);
          }
        }

        if (url.pathname === '/api/cameras') {
          const lat = Number(url.searchParams.get('lat'));
          const lon = Number(url.searchParams.get('lon'));
          const radius = Math.min(2500, Math.max(50, Number(url.searchParams.get('radius')) || 1200));

          if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
            res.statusCode = 400;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: 'Coordenadas inválidas', cameras: [] }));
          }

          const latDelta = radius / 111;
          const lonDelta = Math.min(180, radius / Math.max(10, 111 * Math.cos((lat * Math.PI) / 180)));
          const west = Math.max(-180, lon - lonDelta);
          const east = Math.min(180, lon + lonDelta);
          const south = Math.max(-90, lat - latDelta);
          const north = Math.min(90, lat + latDelta);
          const bbox = [west, south, east, north].map((n) => n.toFixed(4)).join(',');
          const targetUrl = `https://opencctv.org/api/cameras?bbox=${encodeURIComponent(bbox)}&limit=500`;

          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), 9000);
          try {
            const resp = await fetch(targetUrl, {
              headers: { Accept: 'application/json', 'User-Agent': 'OjoDeDios/2.0 public-camera-map' },
              signal: ctrl.signal
            });
            if (!resp.ok) {
              res.statusCode = 200;
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({ provider: 'OpenCCTV', count: 0, cameras: [] }));
            }
            const data = await resp.json();
            const rows = Array.isArray(data) ? data : data.cameras || data.items || data.results || data.features || data.data || [];
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            return res.end(
              JSON.stringify({
                provider: 'OpenCCTV public camera directory',
                attribution: 'Cámaras públicas por operadores. Directorio opencctv.org',
                count: rows.length,
                cameras: rows.slice(0, 500)
              })
            );
          } catch (err) {
            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: 'Directorio público no disponible', cameras: [] }));
          } finally {
            clearTimeout(t);
          }
        }

        if (url.pathname.startsWith('/api/satellite/')) {
          const satId = url.pathname.replace('/api/satellite/', '').toLowerCase();
          const conf = DEFAULT_TLE_MAP[satId];
          if (!conf) {
            res.statusCode = 404;
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ error: 'Not found' }));
          }

          const cached = tleCache.get(satId);
          const now = Date.now();
          if (cached && now - cached.timestamp < 15 * 60 * 1000) {
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ id: satId, tle: cached.data, cached: true }));
          }

          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), 7000);
          try {
            const resp = await fetch(`https://celestrak.org/NORAD/elements/gp.php?CATNR=${conf.catnr}&FORMAT=tle`, { signal: ctrl.signal });
            const text = (await resp.text()).trim();
            if (text.length > 50) {
              tleCache.set(satId, { data: text, timestamp: now });
              res.setHeader('Content-Type', 'application/json');
              return res.end(JSON.stringify({ id: satId, tle: text }));
            }
            throw new Error('Invalid TLE length');
          } catch (e) {
            res.setHeader('Content-Type', 'application/json');
            return res.end(JSON.stringify({ id: satId, tle: cached?.data || conf.fallbackTle, fallback: true }));
          } finally {
            clearTimeout(t);
          }
        }

        next();
      });
    }
  };
}

export default defineConfig({
  plugins: [ojoDeDiosApiPlugin()],
  server: {
    host: '0.0.0.0',
    port: 3000,
    strictPort: true,
    allowedHosts: true,
    hmr: process.env.DISABLE_HMR !== 'true',
    watch: process.env.DISABLE_HMR === 'true' ? null : {}
  },
  preview: {
    allowedHosts: true
  },
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
});
